package com.rangga.seanar.ui.navigation

//onboarding
val splashScreen = "splash_screen"
val loginScreen = "login_screen"
val registerLenderScreen = "register_lender_screen"
val registerBorrowerScreen = "register_borrower_screen"

//Lender
val homeLenderScreen= "home_lender_screen"
val pendanaanLenderScreen= "pendanaan_lender_screen"
val donasiLenderScreen = "donasi_lender_screen"
val profileLenderScreen = "profile_lender_screen"
val detailPendanaanLenderScreen = "detail_pendanaan_lender_screen"
val detailDonasiLenderScreen = "detail_donasi_lender_screen"

//Borrower
val homeBorrowerScreen = "home_borrower_screen"
val donasiBorrowerScreen = "donasi_borrower_screen"
val profileBorrowerScreen = "profile_borrower_screen"
val createFundingBorrowerScreen = "create_funding_borrower_screen"
val createDonasiBorrowerScreen = "create_donasi_borrower_screen"
val detailPendanaanBorrowerScreen = "detail_pendanaan_borrower_screen"
val detailDonasiBorrowerScreen = "detail_donasi_borrower_screen"
